この圧縮ファイルの内容
	ゾンビや狂人が敵を見たときの反応を少しだけ遅くするmodです

modのおもなポイント
	敵を見ているゾンビや狂人が動き始めるまで少しだけ時間がかかるようになります
	窓から姿を一瞬見られても運しだいで大丈夫
	音を立てたり殴ったりしてアピールするものはさすがに見逃されません

色々な表示
	これは、Cataclysm: Dark Days Ahead(https://cataclysmdda.org/)のmodです
	改変その他自由にご利用ください
	動作確認は、experimental build 2023-07-08-0556と0.G安定版で行いました
	0.G安定版でプレイする方は、data/mods/mari_zedSlow/mari_zedSlow_add.jsonを消してご利用ください