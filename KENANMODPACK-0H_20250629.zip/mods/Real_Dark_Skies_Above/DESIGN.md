# The Real Dark Skies Above

This document is intended to not only guide new potential contributors, but also help get my own thoughts on how the game will progress in text. Assume spoilers beyond this point!

# Contributing

You can also contact me, '@Zlorthishen'.  I have a few ideas for directions for this mod which aren't listed in this file. Expect a free season pass DLC named "Peach Trees" soon™.

# Summary of Intent and Content

Mechanically, Real Dark Skies Above, aka Dark Skies is a project to demonstrate how you can push the game engine to present different stories while not blacklisting anyone or anything. Unlike the base game, in Dark Skies a basic narrative arc is assumed, but not required: the player cant find a way to make occupation of Earth too costly for the aliens to continue and die trying, or play the game however they want and still die trying.

In short, Dark Skies is a science fiction/science fantasy story focused around an ongoing alien invasion and the survival of those left in one of the hot-sites: the New England Exclusion Zone, Whilst at the same time functioning as a complementary mod which functions in harmony with any and all other community mods, specifically the UndeadPeople TileSet **Legacy dark skies above Mod is Specifically Prohibited.**


## The World

The Earth presented in Dark Skies is a little closer to our current technology level (things you'd reasonably find in the 21st century). It is still "some time in the near future", and some of the advancements in technology reflect this. The effects of climate change are already starting to increase the severity and frequency of natural disasters, numerous infectious diseases of East Asian origin rage unchecked while tensions between local, regional and national leaders are starting to grow due to global economic depression. As if things couldn't get any worse, astronomical institutions across the globe one day detected a peculiar gravitational anomaly just outside the Moon's orbit, initially considered a quaint discovery before alien spacecraft begin to spill from it...

## The Arrival and The XENOIDS

"The Arrival" is the term for the first few days of the alien invasion, in which various key points of infrastructure were  knocked out: satellites, power plants, highways, and so forth (implying that the aliens have been watching humanity for some time, or at least are familiar with similar systems), and aerial superiority was quickly established in favor of the aliens. Ground based invasion then began, supported by deployment of bioweapons in the form of their Stray strain crystal bio-parasites. The game begins immediately after the Arrival during the ground invasion phase of alien occupation, and ensuing resistance operations by both the US military and any unevacuated civilians still left in the area.

In truth, the aliens themselves are a part of a omnipresent artificial intelligence network dedicated to acquiring resources from other planets by way of tunnelling through the omni-verse. The civilization that originally made it is long dead, and any interesting, vaguely religious aesthetics revering technology are essentially reflections of its birth culture. The network concerns itself with little more than expanding its scope, extracting resources, and refining its tools - though it occasionally will show small glimmers of sapience. It uses a mix of drones and cyborgs made from formerly conquered species to do its bidding, with the ultimate intent of turning planets it comes across to balls of rock hosting innumerable farms and factories. Think a mix between AM from "I Have No Mouth and I Must Scream", the Combine from Half-Life 2, and a little bit of implacable evil The Tyranid Hivemind. 

Being an artificial intelligence unconcerned with cordial contact, the aliens have never identified themselves. Where American government institutions are concerned, "novel opposing force" or simply "NOPFOR" is sufficient in referring to its new extra-dimensional enemy. 

## Alien Technology

Alien technology freshly looted off of a corpse or stripped from a machine is not usable by humans, but there are ways around this. Alien tech usable by humans is broadly split into two categories: "homebrew" and "cracked". These categories are pretty much purely for contributors and have no real place in game.

"Homebrew" is everything crudely assembled out of alien parts that produce effects that weren't perhaps intended by the aliens, but useful to humans none-the-less. Bombs, noisemakers, one-shot laser cannons, and the like are all examples of this. These items are strictly inferior to proper alien tech, but at least somewhat better than items of purely Earth manufacture, if somewhat more temperamental. These items can be made with the help of some human tools (welders, screwdrivers, etc) and are unlocked by completing a recipe that combines several alien components, which in turn generates a recipe "book" called "tinkering notes". Creating "tinkering notes" requires some time investment and prior skill in Earth tech.

"Cracked" items are pieces of alien gear that have been discretely modified to allow human usage, like dedicated grenades, guns, and armor. Unlocking these recipes and executing them requires a similar tinkering process and dedicated alien tools, which are installed in alien outposts. Cracked alien tech provide great boons with fairly minimal drawbacks, but are somewhat difficult to maintain (loss of charge and difficult to repair in particular), due to Earth innately lacking infrastructure to keep them in top shape.


## The Player

The player is a survivor of the chaos of the initial invasion and remains in the New England Exclusion Zone, essentially the Disaster Area except occupied by aliens. They might be very able, or simply very lucky. Outside of very specific starts, they do not know much about the invaders and learn as they go, though eventually a start as a resistance member would be ideal as a sort of jump-start into the narrative arc. Tentatively, players will also be able to select "RP traits" at character creation that will give them some optional interactions with NPCs in the world. These probably won't have significant mechanical benefits, but hopefully will give the player a stronger sense of place in the world.


## The Resistance and the Narrative

Small pockets of resistance have sprung up, groups of both civilians working alone and those who volunteered to help the military. They are hard to find, as any compound of significant size inevitably attracts bombardment. Most are part of a larger overall network that the player can join and do missions for that has contacts with the military, though there are some isolated groups with differing ideologies. Ideally these will only appear after a few months and gradually build up, though the game doesn't quite work like this (yet) and will likely require some dirty tricks using NPC quests. 

Ultimately, the story will revolve around the player discovering that the invasion is commanded by a central construct that is currently on a ship in orbit, finding a way to reach the ship, and having a final showdown. If successful, they will at least buy humanity enough time to figure out a response to any future attacks. This task is made much easier by working with rebel forces, however it should be technically possible to do without... *technically*.


## Other NPCs

Many more humans survived the Arrival and still yet remain in the New England Exclusion Zone. Bandits and looters are more common, but are largely are concerned only with their own survival rather than the lofty ideas of the rebels.



# The Real Dark Skies Above

この文書は、新しい貢献者候補を導くだけでなく、ゲームがどのように進行するかについて私自身の考えをテキストで得るのを助けることを目的としている。ここから先はネタバレを想定してください！

# Contributing
私'@Zlorthishen'に連絡することもできる。 このファイルには記載されていない、このMODの方向性に関するアイデアがいくつかあります。桃の木」という名前の無料シーズンパスDLCを近々期待してください™。

# Summary of Intent and Content
メカニズム的には、Real Dark Skies Above, aka Dark Skiesは、ゲームエンジンをどのようにプッシュすれば、誰も何もブラックリストに入れずに、様々なストーリーを提示できるかを実証するプロジェクトです。ベースとなるゲームとは異なり、Dark Skiesでは基本的なシナリオ・アークが想定されているが、必須ではない。プレイヤーは、エイリアンが地球占領を続けるにはコストがかかりすぎる方法を見つけて死ぬか、好きなようにゲームをプレイして死ぬか、どちらかである。
つまり、Dark Skiesは現在進行中のエイリアンの侵略と、ホットサイトの一つであるニューイングランドの立ち入り禁止区域に残された人々の生存に焦点を当てたSF/サイエンス・ファンタジーの物語であり、同時に他のすべてのコミュニティMOD、特にUndeadPeople TileSetと調和して機能する補完的なMODとして機能します。**

# The World
『Dark Skies』で描かれる地球は、現在の技術水準（21世紀に合理的に見られるもの）に少し近い。まだ 「近未来 」であり、技術の進歩はそれを反映している。気候変動の影響はすでに自然災害の深刻さと頻度を増加させ始めており、東アジア起源の数多くの感染症が野放図に猛威を振るい、世界的な経済不況のために地方、地域、国の指導者間の緊張が高まり始めている。事態がこれ以上悪くなることはないとばかりに、ある日、世界中の天文機関が月の軌道のすぐ外側に特異な重力異常を検出した。当初は風変わりな発見と考えられていたが、異星人の宇宙船がそこから流出し始めた...。

# The Arrival and The XENOIDS
人工衛星、発電所、高速道路などである（エイリアンがしばらくの間人類を監視していたか、少なくとも同様のシステムに精通していることを示唆している）。その後、地上からの侵略が開始され、生物寄生生物であるストレイ系統のクリスタルの生物兵器の配備が支援した。ゲームはアライバルの直後、エイリアンによる占領の地上侵攻の段階から始まり、米軍とまだ避難していない民間人による抵抗活動が続く。
実際のところ、エイリアンそのものは、オムニバースをトンネルで通り抜け、他の惑星から資源を獲得することに特化した、遍在する人工知能ネットワークの一部である。元々これを作った文明はとうの昔に滅んでおり、テクノロジーを崇拝する興味深く漠然とした宗教的美学は、本質的にその誕生文化の反映である。ネットワークは、その範囲を拡大し、資源を抽出し、道具を洗練させることにしか関心がない。ドローンと、かつて征服された種族から作られたサイボーグを混ぜて使い、無数の農場と工場を持つ岩の球に惑星を変えることを究極の目的としている。I Have No Mouth and I Must Scream（私には口がない、叫ばなければならない）」のAMと、「Half-Life 2」のコンバイン、そしてティラニッド・ハイブマインドをミックスしたような存在だ。
友好的な接触に無関心な人工知能であるため、エイリアンは自分たちの正体を明かしていない。アメリカ政府機関にとっては、新たな異次元の敵は 「NOPFOR 」あるいは単に 「NOVER OPASING FORCE 」で十分なのである。

# Alien Technology
死体から略奪したり、機械から剥ぎ取ったばかりのエイリアンのテクノロジーは人間には使えないが、これを回避する方法はある。人間が使用できるエイリアン・テクノロジーは大きく2つに分けられる： 「自作」と「クラック」である。自作 「と 」クラック "の2つのカテゴリーに大別される。
「自作 」とは、エイリアンのパーツを粗雑に組み立てたもので、エイリアンが意図したものではないが、人間にとっては便利な効果をもたらすものである。爆弾、ノイズメーカー、ワンショット・レーザーキャノンなどがその例だ。これらのアイテムは、エイリアンの適切な技術には厳密には劣るが、少なくとも純粋な地球製のアイテムよりはいくらかマシである。これらのアイテムは人間の道具（溶接機、ドライバーなど）の助けを借りて作ることができ、いくつかのエイリアンのコンポーネントを組み合わせたレシピを完成させることでアンロックされる。ティンカリング・ノート "の作成には、ある程度の時間投資と地球技術の事前習得が必要である。
「クラック 」されたアイテムとは、専用のグレネードや銃、アーマーのように、エイリアンの装備品を人間が使用できるように目立たないように改造したものである。これらのレシピをアンロックし、実行するには、エイリアンの前哨基地に設置されている専用のエイリアンの道具と、同じような改造プロセスが必要である。クラックされたエイリアン・テクノロジーは大きな利点をもたらすが、地球にはそれを維持するインフラがないため、維持するのは難しい。

# The Player
プレイヤーは最初の侵略の混乱からの生存者であり、ニューイングランドの立ち入り禁止区域（エイリアンによって占拠されている以外は基本的に災害区域）に残っている。彼らは非常に有能であるかもしれないし、単に非常に幸運であるかもしれない。非常に特殊なスタート以外では、侵略者についてあまり知らないので、その都度学んでいくことになる。しかし、最終的にはレジスタンスの一員としてスタートするのが、物語アークへのジャンプスタートとして理想的だろう。暫定的に、プレイヤーはキャラクター作成時に 「RP特性 」を選択できるようになる。これらはおそらく機械的に大きな利点はないだろうが、願わくばプレイヤーに世界における居場所をより強く感じさせることができるだろう。

# The Resistance and the Narrative
小さなレジスタンスの小集団が生まれた。単独で活動する民間人と、軍を助けるために志願した人々のグループである。大きな規模の施設は必然的に砲撃を受けるため、彼らを見つけるのは難しい。イデオロギーが異なる孤立したグループも存在するが、ほとんどはプレイヤーが参加してミッションを遂行できる、軍とコンタクトを持つ大規模なネットワーク全体の一部である。理想的には、これらは数ヶ月後に現れて、徐々に蓄積されていくのだが、ゲームは（まだ）このようには動いておらず、NPCのクエストを使った汚い手口が必要になるだろう。
最終的には、プレイヤーは侵略が軌道上の船にいる中央構築物によって指揮されていることを発見し、その船に到達する方法を見つけ、最終的な対決をする、というのがストーリーの中心になるだろう。成功すれば、少なくとも人類が今後の攻撃に対する対応を考えるのに十分な時間を稼ぐことができる。この任務は、反乱軍と協力することではるかに容易になるが、技術的には協力しなくても可能なはずだ...。*技術的には

## Other NPCs
多くの人類が生き延びている。
