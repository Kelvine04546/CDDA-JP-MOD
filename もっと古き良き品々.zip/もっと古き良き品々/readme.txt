◆本MODは安定板0.H向けです 2024/12/03
本体同梱MODの「特典アンロックシステム(Bombastic Perks)」のPerkである「古き良き品々」の適用範囲を独断と偏見をもとに拡張するMODです
このMOD「もっと古き良き品々！」は公序良俗に反しない限り改変や再配布や統合など自由に行っていただいて構いません

◆適用範囲（注：本MOD独自に作成）
WW2までに生産されていれば適用
レプリカ・リイシューは適用外の理由にならない
フレーバーによって機構の近代化が示唆されている場合適用外
古い機構(例:ボルトアクション、リボルバー)を採用しているだけでは適用対象にならない
WW2以降の生産だがなんか古さを感じるもの

◆本MODの適用対象と事由
M2ｶｰﾋﾞﾝ　普通に古い
ﾏｶﾛﾌ　比較的古くないが適用してもいいと思った
ｼｬｰﾌﾟｽ　現役かもしれないが古い
ﾚﾏｯﾄﾘﾎﾞﾙﾊﾞｰ　最近のレプリカだが機構が古い
ｺﾙﾄM1860ｱｰﾐｰ　普通に古い
AK-47　比較的古くないが適用してもいいと思った
M1911A1　現役かもしれないが古い
ｳﾍﾞﾙﾃｨ･ｷｬﾄﾙﾏﾝ　最近のレプリカだが機構が古い
SKS　普通に古い
ｵﾌﾞﾚｽﾞ　普通に古い
ﾌﾘﾝﾄﾛｯｸﾗｲﾌﾙ　普通に古い
ｺﾙﾄﾗｲﾄﾆﾝｸﾞ　リイシューだが古い

◆その他
・variantsにフラグは付与できないので諦め
ﾌﾞﾛｰﾆﾝｸﾞｵｰﾄ5　普通に古い
ｲｻｶM37　現役かもしれないが古い

◆バニラの適用リスト(参考)
「廃」は0.H以降の開発版では削除されている(おそらく武器ごと廃止)

〇ハンドガン
Walther PPK(walther_ppk)
Colt M1861 Navy(colt_navy)
S&W Model 10(model_10_revolver)
Browning Hi-Power .40 S&W(hi_power_40)
M1911 pistol(m1911)
Tokarev handgun(tokarev)
Luger P08(p08)
Broomhandle pistol(mauser_c96)
Browning Hi-Power 9x19mm(hi_power_9mm)
Walther P38(walther_p38)
flintlock pistol(pistol_flintlock)
Mossberg Brownie(moss_brownie)廃
FN 1910 .380(fn1910)廃

〇ショットガン
Winchester Model 70(win70)
double barrel shotgun(shotgun_d)
single barrel shotgun(shotgun_s)
bootleg lever-action shotgun(winchester_1887)
6-round trenchgun(winchester_1897)
Winchester M37 .410(shotgun_410)

〇ライフル
small game rifle(marlin_9a)
M1 Garand(garand)
M1903 Springfield(m1903)
Browning Automatic Rifle(m1918)
Enfield battle rifle(smle_mk3)
M1 carbine(m1carbine)
Marlin 1895 SBL(1895sbl)
Mosin battle rifle(mosin91_30)
flintlock carbine(carbine_flintlock)
flintlock musket(rifle_flintlock)
updated Enfield rifle(number4_mki)
M2HB Browning HMG(m2browning)
Mosin carbine(mosin44)
7.7mm battle rifle(type99)
7.7mm sniper rifle(type99_sniper)
.50 caliber rifle(m2browning_sawn)廃

〇サブマシンガン
Thompson M1928A1(tommygun)
M3 SMG(greasegun)
STEN Mk II(sten)
Schmeisser MP 40(mp40)廃
PPSh-41 submachine gun(ppsh)廃

〇ランチャー
3-inch ordnance rifle(cannon_3in_ordnance)

◆今後の展望
ﾌﾞﾛｰﾆﾝｸﾞｵｰﾄ5とｲｻｶM37を単独アイテム化(variantsの削除、つまりバニラjsonの上書きはしない。当代物を異なるアイテムとして実装する)
車載銃のフラグの付け方を調べる(高圧放水砲を見る感じおそらく無理)