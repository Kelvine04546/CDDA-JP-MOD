
function milking(item, active)
    
    local MILK_COOLDOWN = 14400 -- 24時間 6秒で1
    local COW_NAMES = {"cow", "ウシ"}
    local SHEEP_NAMES = {"sheep", "ヒツジ"}
    local DEER_NAMES = {"deer", "シカ"}
    local MOOSE_NAMES = {"moose", "ヘラジカ"}
    local HORSE_NAMES = {"horse", "ウマ"}
    local MILK_AMOUNT = {}
    MILK_AMOUNT["cow"] = 20
    MILK_AMOUNT["sheep"] = 5
    MILK_AMOUNT["deer"] = 5
    MILK_AMOUNT["moose"] = 10
    MILK_AMOUNT["horse"] = 5
    MILK_AMOUNT["cow_h"] = 10
    local MILK_NAME = {}
    MILK_NAME["cow"] = "milk"
    MILK_NAME["sheep"] = "milk_sheep"
    MILK_NAME["deer"] = "milk_deer"
    MILK_NAME["moose"] = "milk_moose"
    MILK_NAME["horse"] = "milk_horse"
    MILK_NAME["cow_h"] = "milk"
    
    local trait_id = trait_id or function(str) return str end
    local turn = (calendar(game.get_calendar_turn())):get_turn()
    
    local charges_per_use = 0
    local ttab = nil
    
    local p = player:pos()
    local setx, sety = game.choose_adjacent("対象を選択", p.x, p.y)
    local tpoint = tripoint(setx, sety, p.z)
    
    if p.x == setx and p.y == sety and player:has_trait(trait_id( "COWBODY" )) then -- 自身の位置 かつ 特定の変異持ちなら
        ttab = {}
        ttab[0] = g:critter_at(tpoint)
        ttab[1] = "cow_h"
        
    else -- 周囲８方向から選択した一ヶ所
        local creature = g:critter_at(tpoint)
        if creature then
            local key = ""
            
            if creature:is_monster() then
                local mon = g:monster_at(tpoint)
                local mtype = mon.type
                
                if mtype:get_meat_itype() == "meat" then -- ゾンビは対象外
                    local n = creature:get_name()
                    for _, v in ipairs(COW_NAMES) do
                        if n == v then
                            key = "cow"
                            break
                        end
                    end
                    for _, v in ipairs(SHEEP_NAMES) do
                        if n == v then
                            key = "sheep"
                            break
                        end
                    end
                    for _, v in ipairs(DEER_NAMES) do
                        if n == v then
                            key = "deer"
                            break
                        end
                    end
                    for _, v in ipairs(MOOSE_NAMES) do
                        if n == v then
                            key = "moose"
                            break
                        end
                    end
                    for _, v in ipairs(HORSE_NAMES) do
                        if n == v then
                            key = "horse"
                            break
                        end
                    end
                end
            elseif creature:is_npc() and creature:has_trait( trait_id( "COWBODY" )) then -- 対象が人間(NPC)でかつ特定の変異を起こしていたら
                key = "cow_h"
            end
                
            if key ~= "" then
                ttab = {}
                ttab[0] = creature
                ttab[1] = key
            end
        end
    end
    
    if ttab == nil then
        game.add_msg("対象となる生物がいない！")
        return
    end
        
    local creature = ttab[0]
    local key = ttab[1]
            
    local max = MILK_AMOUNT[key]
    local effect = "milking_" .. key
    local adddur = math.floor(MILK_COOLDOWN / max) -- １個あたりの生成に何ターン必要か(切り捨て)
            
    local preturn = tonumber(creature:get_value("milking_turn")) or turn - (adddur * max) -- 前回のターン取得 or 初搾乳ならmax分計算
    preturn = math.max(preturn, turn - (adddur * max)) -- 最低値引き上げ
    local precharges = math.floor((turn - preturn) / adddur)
    
    if precharges <= 0 then
        game.add_msg(creature:disp_name() .. " からはまだ搾乳できない！")
        return
    end
    
    local milk = item(MILK_NAME[key], -1, precharges) -- 内部的にアイテム生成
            
    local is_milk_use = 0
    while milk.charges >= 1 do
        if g:handle_liquid(milk) then
            if milk.charges < precharges then -- 飲む、容器、捨てるを選択した場合
                local r = precharges - milk.charges -- 消費量
                charges_per_use = charges_per_use + (r * 2) -- 充填の消費量計算と加算
                creature:add_effect(efftype_id(effect), r * adddur) -- 対象に effect付与 か 効果時間加算
                preturn = preturn + (r*adddur)
                precharges = milk.charges
                is_milk_use = 1
            end
        else -- キャンセル時
            break
        end
    end
    
    creature:set_value("milking_turn", tostring(preturn-is_milk_use))
    if item.charges == 0 then
        player:consume_charges(item, charges_per_use)
    else
        item.charges = math.max(0, item.charges - charges_per_use)
    end
end
 
game.register_iuse("IUSE_MILKING_GET_ITEM", milking)