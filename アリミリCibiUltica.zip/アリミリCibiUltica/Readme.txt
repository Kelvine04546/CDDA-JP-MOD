CibiUltica向けCoeFontアリアル・ミリアルのキャラチップです。修正・改変などご自由にお使いください。
PSDファイルでは衣装や髪などをレイヤー分けしております。

作ったキャラ
CoeFont アリアル・ミリアル
https://CoeFont.cloud
