
○Activated_Carbon(追加 - 活性炭による解毒) 0.E-3用
    "id": "ActivatedCarbon"
    "category": "rebalance"

○このModの作成にあたって、サメバーガーさんのMod(NMW_project、解毒結晶のeffect)を参考にさせていただきました。深く感謝します！


○初期から連れ添った仲間が蜘蛛ゾンビの毒ガスで全滅したので作りました。理不尽死はつらい。
  
  主に解毒手段を追加するModです。追加された"活性炭"を飲むことでpoisonとbadpoisonを治療できるようになります。
  同様に、酸素ボンベ系を"摂取する"ことによって毒を治せるようにしました。アイテム説明に煙吸ったら使えってあるしね。
  レシピはサバイバル1～2で覚えるほか、サバイバルの学習本から習得できます。
  
  また、NPCの装備向けにガスマスク系統の最大充填量を増やしてあります。(小型マスク:100→150  中型マスク:100→300)
  いらないって人は"AcCa_gasmask_buff.json"を削除することで取り除けます。


○参考にしたサイト
https://www.wikihow.jp/%E6%B4%BB%E6%80%A7%E7%82%AD%E3%82%92%E4%BD%9C%E3%82%8B#aiinfo
https://www.survivopedia.com/how-to-make-activated-carbon/
