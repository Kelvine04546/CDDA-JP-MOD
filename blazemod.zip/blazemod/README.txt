This is the last test candidate version for the re-worked blazemod with backwards compatibility. 

Use instead of the new Blaze Industries mod in latest experimentals if continuing an with blazemod in it. Uninstall any turrets and turret-frames from 
your vehicles before updating to use this version to avoid segfault crashes.

If you're using the CDDA Launcher by RemyRoy, you can instead put this new blazemod folder in \CDDA Game Launcher\cdda\mods instead of the usual
\CDDA Game Launcher\cdda\data\mods\ and it will stop being replaced every time you update.

If you have any issues or encounter any bugs related to the use of this mod, please let me know @SouP#7927 in either CDDA discord, or comment on the Github
page at https://github.com/CleverRaven/Cataclysm-DDA/pull/37497 or even on discourse, and I'll try to respond.

In the future I will make a migration mod that will allow for a one-off migration from this mod to the new Blaze Industries for anyone who might be
interested, but it is not an immediate priority.


これは、後方互換性を持たせて再構築されたblazemodの最後のテスト候補バージョンです。

blazemodを組み込んだゲームを継続する場合は、最新のBlaze Industries MODの代わりに使用してください。タレットとタレットフレームをアンインストールしてください。
segfaultのクラッシュを避けるため、このバージョンを使用するようにアップデートする前に、車両からタレットとタレットフレームをアンインストールしてください。

RemyRoyのCDDA Launcherを使用している場合、代わりにこの新しいblazemodフォルダを通常の
\に置けば、アップデートの度に入れ替わらなくなります。

このMODの使用に関して何か問題やバグがあったら、CDDAのディスコードかGithubのコメントで@SouP#7927までお知らせください。
https://github.com/CleverRaven/Cataclysm-DDA/pull/37497 のページ、あるいはdiscourseのコメントでお知らせください。

将来的には、このMODから新しいBlaze Industriesに一度だけ移行できるMODを作るつもりです。
しかし、すぐに優先すべきことではありません。
