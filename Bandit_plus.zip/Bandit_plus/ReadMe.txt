Bandit_plus

Prerequisite mod: None
Supported versions: 0.G
version:0.1

made by gunnokagami

------------------------------------------------------------------------------------------------------------------------------------------------------------

This mod adds hostile survivor bandits as monsters.
They are armed with small arms and have an aggressive attitude toward zombies and players.
They have higher intelligence than zombies and will avoid obstacles or retreat if wounded. Some individuals use searchlights to illuminate their targets.
Bandits are powerful enemies that require a different strategy and attention than zombies. Combat with them may be not only dangerous but also rewarding.
Resources such as weapons, ammunition, food and medicine taken from Bandits will help you survive.

------------------------------------------------------------------------------------------------------------------------------------------------------------

敵対的な生存者であるバンディットをモンスターとして追加するMODです。
彼らは小火器で武装しており、ゾンビやプレイヤーに対して攻撃的な態度をとります。
彼らはゾンビよりも高い知能を持っており、障害物を避けたり、傷を負えば退却するでしょう。サーチライトで目標を照らす個体も居ます。
バンディットは、ゾンビとは異なる戦略と注意力を要求する強力な敵です。彼らとの戦闘は、危険だけでなく、報酬も大きいかもしれません。
バンディットから奪った武器や弾薬、食料や薬などの資源は、生き残るために役立つでしょう。

------------------------------------------------------------------------------------------------------------------------------------------------------------

#TODO
バンディットの種類を増やす
バンディットの攻撃手段を増やす
バンディットのスポーン地点を増やす
バンディットとは敵対する別の生存者（モンスター）を増やす（もちろんプレイヤーとも敵対！）
バンディットのタイルを追加
翻訳ファイルの追加（やり方分からん）
GitHubへの移行
