CibiUltica向けCoeFontアリアル・ミリアルのキャラ画像MODです。修正・改変などご自由にお使いください。
allimilli_cibiulticaフォルダをdata/modsフォルダに入れる事で＠さんをCoeFontアリアル・ミリアルの姿に変えて遊べます。
PSDファイルでは衣装や髪などをレイヤー分けしております。

作ったキャラ
CoeFont アリアル・ミリアル
https://CoeFont.cloud

MOD化の際に参考にした物
VOICEROID+Ex_mod

【Cataclysm:DDA】いじってあそぼ【スキン追加】
https://www.nicovideo.jp/watch/sm39856384

変更履歴
2023/7/16 画像のみで公開
2023/7/16 画像の位置がずれていたのを修正しスキンMOD化
